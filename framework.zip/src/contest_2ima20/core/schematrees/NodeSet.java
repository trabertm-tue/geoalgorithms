/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package contest_2ima20.core.schematrees;

import java.util.ArrayList;

/**
 *
 * @author wmeulema
 */
public class NodeSet extends ArrayList<Node> {

    public final int id;

    public NodeSet(int id) {
        this.id = id;
    }

}
