package contest_2ima20.client.gui;

import contest_2ima20.core.problem.Problem;

public interface ProblemListener {

    void updateProblem(Problem p);
}
