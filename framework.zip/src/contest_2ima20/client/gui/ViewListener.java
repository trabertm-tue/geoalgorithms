package contest_2ima20.client.gui;

import contest_2ima20.core.problem.Viewable;

public interface ViewListener {
    void updateView(Viewable v);
}
